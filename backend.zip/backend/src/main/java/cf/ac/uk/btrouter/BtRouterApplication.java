package cf.ac.uk.btrouter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtRouterApplication {

    public static void main(String[] args) {
        SpringApplication.run(BtRouterApplication.class, args);
    }

}
