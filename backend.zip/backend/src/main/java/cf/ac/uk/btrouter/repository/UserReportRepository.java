package cf.ac.uk.btrouter.repository;

import cf.ac.uk.btrouter.model.UserReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserReportRepository extends JpaRepository<UserReport, Long> {
}
